<template>
  <el-footer>
      footer
  </el-footer>
</template>

<style scope>
.el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
  }
</style>